# Logos

Todos os arquivos são SVG em curvas (sem dependência de fonte), com tinta fixa. Para fundo claro, use as versões `pergaminho`; para fundo escuro, as versões `capela`; sobre um cartão inteiro na cor do dia, a versão `sobre-cor`.

- `logo-horizontal-pergaminho.svg` — assinatura horizontal; logotipo em `tinta` #241b14, símbolo em `ouro` #866420.
- `logo-horizontal-capela.svg` — assinatura horizontal; logotipo em `tinta` #f3eadb, símbolo em `ouro` #cfa956.
- `logo-horizontal-sobre-cor.svg` — assinatura horizontal com símbolo e logotipo em `sobre-cor` #faf6ee, para o cartão inteiro na cor do dia (o último do Evangelho). Passa de 5:1 sobre as cinco cores litúrgicas; o símbolo em ouro ficaria abaixo de 3:1 no cartão ouro e no rosa.
- `logo-vertical-pergaminho.svg` — símbolo sobre o logotipo; mesmas tintas da horizontal pergaminho.
- `logo-vertical-capela.svg` — símbolo sobre o logotipo; mesmas tintas da horizontal capela.
- `simbolo-pergaminho.svg` — só o símbolo, em `ouro` #866420.
- `simbolo-capela.svg` — só o símbolo, em `ouro` #cfa956.
- `simbolo-reduzido-pergaminho.svg` — símbolo sem o filete interno, para menos de 40 px; `ouro` #866420.
- `simbolo-reduzido-capela.svg` — o mesmo em `ouro` #cfa956.
- `avatar-perfil.png` — foto de perfil 1080 × 1080: símbolo em `ouro` #cfa956 sobre `fundo` capela #16110d.
- `avatar-perfil.svg` — a mesma foto de perfil em vetor, para editar no Canva.
