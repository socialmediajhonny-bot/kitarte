# Logos

Todos os arquivos são SVG em curvas (sem dependência de fonte), com tinta fixa. Para fundo claro, use as versões `pergaminho`; para fundo escuro ou sobre cor litúrgica, as versões `capela`.

- `logo-horizontal-pergaminho.svg` — assinatura horizontal; logotipo em `tinta` #241b14, símbolo em `ouro` #866420.
- `logo-horizontal-capela.svg` — assinatura horizontal; logotipo em `tinta` #f3eadb, símbolo em `ouro` #cfa956.
- `logo-vertical-pergaminho.svg` — símbolo sobre o logotipo; mesmas tintas da horizontal pergaminho.
- `logo-vertical-capela.svg` — símbolo sobre o logotipo; mesmas tintas da horizontal capela.
- `simbolo-pergaminho.svg` — só o símbolo, em `ouro` #866420.
- `simbolo-capela.svg` — só o símbolo, em `ouro` #cfa956.
- `simbolo-reduzido-pergaminho.svg` — símbolo sem o filete interno, para menos de 40 px; `ouro` #866420.
- `simbolo-reduzido-capela.svg` — o mesmo em `ouro` #cfa956.
- `avatar-perfil.png` — foto de perfil 1080 × 1080: símbolo em `ouro` #cfa956 sobre `fundo` capela #16110d.
- `avatar-perfil.svg` — a mesma foto de perfil em vetor, para editar no Canva.
