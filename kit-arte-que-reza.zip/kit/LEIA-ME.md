# Kit Arte que Reza · versão 4

Exportado do design system "Arte que Reza" (claude.ai) em 28/10/2026. É a fonte da verdade das artes: não edite estes arquivos. Se algo precisar mudar, a mudança vai primeiro para o design system e depois um kit novo é exportado.

## O que mudou desde a versão 3

- **Para Rezar:** `componentes/PostOracao/README.md` ganhou a regra da oração longa e as medidas. Acima de cerca de 400 caracteres, a oração vira carrossel: o primeiro card leva título, ornamento e o começo do texto; os seguintes, só a continuação, centralizada, com a contagem ("2/2") no lugar da intenção; a origem fica no último card. Título até duas linhas; até 10 linhas de oração no primeiro card e até 14 nos seguintes.
- **Prévia do Para Rezar:** `componentes/PostOracao/preview.html` mostra o card único (São Miguel) e o carrossel de dois cards (Ato de Contrição de 15/12).
- **Coragem:** `componentes/PostCoragem/README.md` limita a frase a duas linhas (cerca de 50 caracteres). Com três, a frase ficava a 22 px do nicho no feed. O crédito da obra vai na legenda.
- **Nicho:** `componentes/Nicho/README.md` ganhou a regra "só a pintura": a margem cinza ou branca da foto do museu e a borda do painel ficam fora do arco; aproxime a obra até sumirem. No santinho, aproxime até o rosto ficar legível.
- **Sem mudança visual:** `tokens.json`, `bundle.css`, logos e fontes são os mesmos da versão 3, byte a byte. As artes já geradas não mudam.

## O que mudou na versão 3

- **Card de festa:** `componentes/PostFesta/` (README e prévia), no lugar do santinho nas solenidades e festas do Senhor e de Nossa Senhora.
- **Santinho:** medidas no `componentes/PostSanto/README.md` e a regra de quando vira card de festa.
- **Corpo equilibrado:** no `bundle.css`, `.aqr-corpo` passou de `text-wrap: pretty` para `balance`.

## O que mudou na versão 2

- **Logo novo:** `logos/logo-horizontal-sobre-cor.svg`, para o cartão inteiro na cor do dia.
- **Evangelho do Dia:** os quatro cards do domingo em `componentes/PostEvangelho/`.
- **Quebra de linha:** palavra de uma letra (a, à, e, é, o) não fica no fim da linha.

## O que tem aqui

- `design-system/README.md`: o manual da marca.
- `design-system/tokens.json`: cores (dois temas e cinco litúrgicas), tipografia, espaços, raios e formatos. Valores entre chaves, como `{ouro}`, apontam para outro token.
- `design-system/bundle.css`: a composição das peças e dos modelos.
- `design-system/componentes/<Peça>/`: README e prévia HTML de cada peça (Selo, Nicho, Assinatura) e de cada modelo (PostEvangelho, PostSanto, PostFesta, PostOracao, PostCoragem, StoryAngelus, GradeFeed).
- `logos/`: os onze arquivos do grupo Logos. Os SVG estão em curvas, mas o símbolo é desenhado com traço (`stroke`).
- `fontes/`: Cormorant Garamond (Medium, Medium Italic, SemiBold, SemiBold Italic) e Lato (Regular, Bold) em TTF, com as licenças OFL.

## O que mudou na exportação

- Os logos ganharam o nome do grupo Logos; no design system eram guardados por um código.
- As fontes passaram de WOFF2 para TTF. Os quatro arquivos da Cormorant se chamavam "Cormorant Garamond Light" por dentro, apesar de serem Medium e SemiBold; os nomes internos foram corrigidos e o desenho das letras não mudou.
- Nos `preview.html`, os caminhos `/_blob/...` viraram caminhos para `logos/`.

## Para ler os preview.html

Eles usam variáveis CSS (`--fundo`, `--cor-do-dia`, `--espaco-3`…) e classes de texto com o nome dos estilos (`.selo`, `.titulo`, `.citacao`…), que o app do design system gerava a partir do `tokens.json`. Fora do app, isso precisa ser gerado num `tokens.css`, junto com os `@font-face` das fontes desta pasta.
