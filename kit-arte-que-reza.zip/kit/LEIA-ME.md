# Kit Arte que Reza

Exportado do design system "Arte que Reza" (claude.ai) em 15/10/2026. É a fonte da verdade das artes: não edite estes arquivos. Se algo precisar mudar, a mudança vai primeiro para o design system e depois um kit novo é exportado.

## O que tem aqui

- `design-system/README.md`: o manual da marca.
- `design-system/tokens.json`: cores (dois temas e cinco litúrgicas), tipografia, espaços, raios e formatos. Valores entre chaves, como `{ouro}`, apontam para outro token.
- `design-system/bundle.css`: a composição das peças e dos modelos.
- `design-system/componentes/<Peça>/`: README e prévia HTML de cada peça (Selo, Nicho, Assinatura) e de cada modelo (PostEvangelho, PostSanto, PostOracao, PostCoragem, StoryAngelus, GradeFeed).
- `logos/`: os dez arquivos do grupo Logos. Os SVG estão em curvas, mas o símbolo é desenhado com traço (`stroke`).
- `fontes/`: Cormorant Garamond (Medium, Medium Italic, SemiBold, SemiBold Italic) e Lato (Regular, Bold) em TTF, com as licenças OFL.

## O que mudou na exportação

- Os logos ganharam o nome do grupo Logos; no design system eram guardados por um código.
- As fontes passaram de WOFF2 para TTF. Os quatro arquivos da Cormorant se chamavam "Cormorant Garamond Light" por dentro, apesar de serem Medium e SemiBold; os nomes internos foram corrigidos e o desenho das letras não mudou.
- Nos `preview.html`, os caminhos `/_blob/...` viraram caminhos para `logos/`.

## Para ler os preview.html

Eles usam variáveis CSS (`--fundo`, `--cor-do-dia`, `--espaco-3`…) e classes de texto com o nome dos estilos (`.selo`, `.titulo`, `.citacao`…), que o app do design system gerava a partir do `tokens.json`. Fora do app, isso precisa ser gerado num `tokens.css`, junto com os `@font-face` das fontes desta pasta.
