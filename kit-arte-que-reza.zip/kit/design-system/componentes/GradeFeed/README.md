# GradeFeed

Como três dias de publicação aparecem no perfil, nas miniaturas 3:4 que o Instagram recorta do post 4:5; a mais nova fica em cima, à esquerda.

- **O que mostra:** a coluna da direita é sempre o Evangelho (capela), a do meio o santinho (pergaminho) e a da esquerda a série da noite, que alterna. A cor muda com o dia: ouro na quinta (Santa Teresa), verde na sexta (dia comum), vermelho no sábado (Santo Inácio de Antioquia).
- **Séries sem modelo próprio:** Toda Bela segue a capa do Evangelho; Rezo por Você e Por Dentro da Missa seguem o card de oração, com `titulo-capa` e `corpo`.
- **Leitura:** o domingo tem um post a menos, então a coluna de cada série desliza uma posição por semana. Isso é esperado.
