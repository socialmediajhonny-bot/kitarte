# PostFesta

Card da solenidade ou da festa, no lugar do santinho, às 9h: tema `pergaminho`, a obra da celebração no `Nicho` e o nome da festa em `titulo-capa`.

- **Quando:** solenidades e festas do Senhor e de Nossa Senhora, como Imaculada Conceição, Guadalupe e Natal. Festa de santo (Santo André, Santo Estêvão) continua no santinho.
- **Estrutura:** selo com o grau no lugar do nome da série ("Solenidade · ter, 8 dez") e nada à direita; nicho 600 × 680; crédito da obra em uma linha; nome da celebração em `titulo-capa`, até duas linhas, com 880 px de largura; assinatura.
- **O que fornecer:** a data, o grau (Solenidade ou Festa), a cor, o nome da celebração e a obra com crédito.
- **Cor:** a da celebração, quase sempre `liturgico-branco` (o ouro), na cruz do selo e no filete do nicho.
- **Sem moldura e sem frase:** é o que separa a festa do santinho na grade. A obra e o nome bastam; a explicação da festa vai na legenda.
