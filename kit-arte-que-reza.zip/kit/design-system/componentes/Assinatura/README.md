# Assinatura

O logotipo centralizado na base de toda arte, a `espaco-5` da borda, com 52 px de altura na assinatura horizontal.

- **Qual arquivo:** `logo-horizontal-pergaminho.svg` sobre `fundo` claro; `logo-horizontal-capela.svg` sobre `fundo` escuro; `logo-horizontal-sobre-cor.svg` sobre um cartão inteiro na cor do dia. A vertical vai em capas, destaques e materiais impressos.
- **Assinatura com @:** nas artes feitas para circular fora do Instagram (Coragem, status do WhatsApp), acrescente "@artequereza.oficial" no estilo `assinatura`, em `tinta-suave`, a `espaco-3` do logotipo.
- **Assinatura curta:** `simbolo-reduzido` + @ quando a arte é pequena ou o espaço é estreito.
- **Foto de perfil:** `avatar-perfil.png` (1080 × 1080). O Instagram recorta em círculo; o símbolo já está dimensionado para isso.
- **Área de proteção:** a largura da travessa da cruz em volta do logo. Nada encosta nele.
