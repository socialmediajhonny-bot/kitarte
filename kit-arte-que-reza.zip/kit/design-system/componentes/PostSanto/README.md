# PostSanto

O Santo do Dia como um santinho: tema `pergaminho`, cartão em `papel` com moldura dupla em `ouro`, retrato no `Nicho` e a frase do santo.

- **Estrutura:** selo com o grau da celebração à direita; dentro do cartão, nicho 340 × 420, nome em `titulo`, título do santo em `corpo` e `tinta-suave` ("Virgem e Doutora da Igreja"), ornamento, frase em `citacao` entre aspas curvas e a fonte em `credito`.
- **O que fornecer:** o nome, o título, a data, o grau, a obra, a frase e a fonte (obra, carta, sermão).
- **Cor:** `liturgico-vermelho` para mártires e `liturgico-branco` para os demais, na cruz do selo e no filete do nicho.
- **Medidas:** nome em uma linha; frase até três linhas, com 700 px de largura; fonte em uma linha. Tudo cabe dentro da moldura, sem encostar no filete interno.
- **Crédito da obra:** vai na legenda, não no cartão.
- **Regras:** frase sem fonte não sai. Santo sem escritos ganha uma frase sobre ele, com a fonte, ou "a lição do santo" escrita pela página e assumida como dela. Domingo não tem Santo do Dia. Solenidades e festas do Senhor e de Nossa Senhora trocam o santinho pelo `PostFesta`; festa de santo continua no santinho, com "Festa" no selo.
