# StoryAngelus

Story fixo do meio-dia, tema `capela`, publicado todos os dias às 12h com a mesma arte.

- **Estrutura:** selo "Para Rezar · 12h", Anunciação no `Nicho` (600 × 700), título "Ângelus" em `titulo-capa`, uma linha em `corpo`, ornamento, o primeiro versículo em `citacao` e a resposta em `oracao`.
- **Tempo Pascal:** troque pelo Regina Caeli, com a mesma composição.
- **Margens:** `espaco-6` no topo e na base, por causa da barra do perfil e do campo de resposta.
- O story das 15h (Hora da Misericórdia) segue a mesma composição.
