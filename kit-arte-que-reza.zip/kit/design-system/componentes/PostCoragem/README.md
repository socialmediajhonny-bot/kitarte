# PostCoragem

A frase da semana, feita para ser encaminhada: tema `pergaminho`, uma imagem serena no `Nicho`, a frase em `citacao-grande` e a referência em `referencia`.

- **Estrutura:** selo, nicho 600 × 680 (720 × 900 no status), frase de até duas linhas, referência em `ouro`, assinatura com "@artequereza.oficial".
- **Medidas:** cabem cerca de 50 caracteres em duas linhas. Uma terceira linha deixa a frase a menos de 30 px do nicho no feed; corte a frase em vez de diminuir a letra.
- **O que fornecer:** a frase, da Escritura ou de um santo, e a referência exata.
- **Formatos:** sempre feed (1080 × 1350) e status/story (1080 × 1920). A arte precisa se sustentar sozinha no WhatsApp, por isso leva o @.
- **Crédito da obra:** vai na legenda, não na arte.
- **Regras:** esperança, não autoajuda. Nada de "acredite em você" ou frases sem autor.
