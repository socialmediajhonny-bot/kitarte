# PostOracao

Card da série Para Rezar, tema `pergaminho`: a oração inteira e legível, feita para salvar e rezar depois.

- **Estrutura:** selo com a intenção à direita ("para pedir proteção"), título em `titulo`, ornamento, texto em `oracao` com no máximo 880 px de largura, origem em `credito`.
- **O que fornecer:** a oração na versão usada no Brasil, o título, a intenção e a origem.
- **Oração longa:** acima de cerca de 400 caracteres, vira carrossel. O primeiro card leva o título, o ornamento e o começo da oração; os seguintes, só a continuação, centralizada, com a contagem no lugar da intenção ("2/2"). A origem fica no último card. Divida no ponto ou no ponto e vírgula, nunca no meio de uma frase.
- **Medidas:** título em até duas linhas; até 10 linhas de oração no primeiro card e até 14 nos seguintes. Nesses limites, o texto fica a pelo menos 60 px do selo e da assinatura.
- **Regras:** só orações tradicionais ou de fonte conhecida. Oração a Nossa Senhora vai para a série Toda Bela; oração em família, para Igreja Doméstica.
