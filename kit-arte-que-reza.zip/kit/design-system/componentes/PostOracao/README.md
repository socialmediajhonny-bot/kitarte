# PostOracao

Card da série Para Rezar, tema `pergaminho`: a oração inteira e legível, feita para salvar e rezar depois.

- **Estrutura:** selo com a intenção à direita ("para pedir proteção"), título em `titulo`, ornamento, texto em `oracao` com no máximo 880 px de largura, origem em `credito`.
- **O que fornecer:** a oração na versão usada no Brasil, o título, a intenção e a origem.
- **Regras:** só orações tradicionais ou de fonte conhecida. Até cerca de 400 caracteres por card; acima disso, carrossel com o texto dividido em frases inteiras. Oração a Nossa Senhora vai para a série Toda Bela; oração em família, para Igreja Doméstica.
