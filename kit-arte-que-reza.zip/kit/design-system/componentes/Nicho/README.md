# Nicho

Moldura em arco pleno para a obra principal de toda arte: o topo em `raio-arco`, um filete de 3 px na `cor-do-dia` a `espaco-2` da obra e um parapeito de 3 px que passa `espaco-4` para cada lado.

- **O que fornecer:** a obra (pintura, ícone, vitral, escultura ou foto própria) e o tamanho externo. Medidas em uso: 680 × 760 na capa do Evangelho, 340 × 420 no santinho, 600 × 680 no Coragem, 640 × 760 no Toda Bela, 720 × 900 e 600 × 700 nos stories.
- **Cor do filete:** a `cor-do-dia`; para fixar outra, defina `--moldura` no nicho.
- **Enquadre** o rosto e o gesto principal no centro do arco. Se o arco cortar algo essencial, aumente a largura do nicho antes de cortar a obra.
- **Só a pintura:** a margem cinza ou branca da foto do museu e a borda do painel ficam fora do arco. Aproxime a obra até sumirem. No santinho, que é pequeno, aproxime até o rosto ficar legível, mesmo que uma inscrição na base do quadro fique de fora.
- **Não faça:** texto ou logo sobre a obra, cantos arredondados embaixo, filete dourado falso, sombra.
- Nas prévias, o degradê marca o lugar da obra.
