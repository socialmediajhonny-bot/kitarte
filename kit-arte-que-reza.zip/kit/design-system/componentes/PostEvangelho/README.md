# PostEvangelho

Carrossel diário do Evangelho do Dia, tema `capela`, publicado às 6h: três cards nos dias de semana e quatro no domingo.

1. **Capa:** a cena do Evangelho no `Nicho` (680 × 760), o crédito da obra em uma linha e um título de até duas linhas em `titulo`, escrito com suas palavras ("O Senhor vem. Fique acordado.").
2. **Versículo-chave:** a mesma composição sem o nicho. No centro, o trecho sem aspas, em `citacao-grande` até três linhas; se não couber, em `citacao`, até quatro. Logo abaixo, a referência exata do trecho em `referencia` ("Mc 13,37").
3. **Para a Missa de hoje** (só no domingo): no centro, "Para a Missa de hoje" no estilo `selo` em `tinta-suave`, um título de até duas linhas em `titulo`, o ornamento e até seis linhas em `corpo`, com 760 px de largura.
4. **Para rezar hoje:** cartão inteiro na `cor-do-dia` (valores do tema `pergaminho`): "Para rezar hoje" no estilo `selo`, uma pergunta em `citacao` (até quatro linhas, 860 px), o ornamento e "Abra sua Bíblia em [referência por extenso]" em `corpo`. Tudo em `sobre-cor`, com a assinatura `logo-horizontal-sobre-cor.svg`.

- **Selo:** em todos os cards, "Evangelho do Dia" com a data e, à direita, a referência completa ("Mc 13,33-37").
- **O que fornecer:** a data, a cor, a referência, o título, a obra com crédito, o trecho com a referência exata, a pergunta e, no domingo, o título e o texto da reflexão.
- **Regras:** na arte vai só um trecho curto, nunca o texto inteiro da tradução litúrgica. A cor segue o dia: verde nos dias comuns, roxo no Advento e na Quaresma, ouro nos dias brancos e nas memórias de santos não mártires, vermelho nas de mártires, rosa em Gaudete e Laetare.
- **Quebra de linha:** título e trecho aceitam quebra manual, para separar frases ("O Senhor vem. / Fique acordado."); sem ela, as linhas saem equilibradas.
- **Domingo:** o card de reflexão entra antes do "Para rezar hoje", porque é o Evangelho que a pessoa vai ouvir na Missa.
