# PostEvangelho

Carrossel diário do Evangelho do Dia em três cards, tema `capela`, publicado às 6h.

1. **Capa:** selo com a referência à direita, a cena do Evangelho no `Nicho` (680 × 760), o crédito da obra e um título de até duas linhas em `titulo`, escrito com suas palavras ("Nem um pardal é esquecido por Deus").
2. **Versículo-chave:** a mesma composição sem o nicho, com o trecho em `citacao` no centro e a referência em `referencia`.
3. **Para rezar hoje:** cartão inteiro na `cor-do-dia` (valores do tema `pergaminho`), uma pergunta em `citacao` e "Abra sua Bíblia em [referência]" em `corpo`, tudo em `sobre-cor`.

- **O que fornecer:** a data, a referência, o título, a obra com crédito, o trecho-chave e a pergunta.
- **Regras:** na arte vai só um trecho curto, nunca o texto inteiro da tradução litúrgica. A cor segue o dia: verde nos dias comuns, ouro nas memórias de santos não mártires, vermelho nas de mártires.
- **Domingo:** a mesma estrutura com um card a mais de reflexão, porque é o Evangelho que a pessoa vai ouvir na Missa.
