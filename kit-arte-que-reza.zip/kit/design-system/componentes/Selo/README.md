# Selo

Cabeçalho de toda arte: uma cruz na `cor-do-dia`, o nome da série no estilo `selo` e a data em `tinta-suave`.

- **Onde:** no topo, à esquerda, encostado na margem de `espaco-5`. À direita, opcional, uma informação de apoio em `tinta-suave`: a referência bíblica, o grau da celebração ("Memória") ou a contagem do carrossel ("1/4").
- **O que fornecer:** o nome da série como está na linha editorial, a data no formato "sex, 16 out" e, se houver, a informação de apoio.
- **Cor da cruz:** a `cor-do-dia`. No Santo do Dia, a cor do santo: `liturgico-vermelho` para mártires, `liturgico-branco` para os demais. Sobre um cartão inteiro na cor do dia, a cruz fica em `sobre-cor`.
- **Não faça:** caixa alta, um segundo ícone, a cruz em `tinta`, mais de uma cor no mesmo selo.
