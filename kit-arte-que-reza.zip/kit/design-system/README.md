Arte que Reza é uma página de Instagram de imagens católicas diárias que evangeliza pela beleza. Toda arte parte de uma obra sacra real, posta num nicho em arco; o selo diz a série e a data, e a cor do tempo litúrgico aparece em dois pontos, sempre os mesmos. O tom é inspirador, acolhedor e autêntico.

## Princípios

- **A obra é a protagonista.** Use pintura, ícone, vitral, escultura ou foto própria de igreja. Nunca use IA no rosto de Jesus, de Maria ou dos santos.
- **O nicho é a assinatura visual.** A imagem principal de toda arte entra no componente `Nicho`, com o topo em `raio-arco`.
- **A cor do dia aparece pouco e no mesmo lugar:** a cruz do `Selo` e o filete do `Nicho`, ambos lendo `cor-do-dia`.
- **Obra pede capela, texto pede pergaminho.** Evangelho do Dia, Olhe de Novo e Toda Bela usam o tema `capela`. Santo do Dia (o santinho), Para Rezar, Coragem, Por Dentro da Missa, Rezo por Você, Igreja Doméstica e Novenas usam `pergaminho`. Assim o perfil alterna claro e escuro sozinho.
- **Pouco texto, muito respiro.** Margem de `espaco-5` nas quatro bordas; no máximo um título e uma frase por card.
- **Caixa alta e baixa.** Nomes de série, títulos e datas nunca em caixa alta.

## Logo

- **Símbolo:** um nicho em arco pleno com moldura dupla, traço grosso por fora e filete por dentro, e uma cruz latina de pé sobre o parapeito. O contraste grosso e fino repete a modulação da Cormorant; a haste da cruz é mais grossa que a travessa, como nas letras.
- **Logotipo:** "Arte" e "Reza" em Cormorant Garamond SemiBold, "que" em Cormorant Medium Italic a 74%. Os arquivos estão em curvas e não dependem de fonte instalada.
- **Qual arquivo usar** (grupo Logos): a versão `pergaminho` sobre fundo claro, com logotipo em `tinta` e símbolo em `ouro`; a versão `capela` sobre fundo escuro; a versão `sobre-cor`, com símbolo e logotipo em `sobre-cor`, sobre um cartão inteiro na cor do dia, onde o símbolo em ouro perderia contraste. Assinatura horizontal na base das artes; vertical em capas, banners e no destaque do perfil.
- **Área de proteção:** deixe livre, em volta do logo, a largura da travessa da cruz.
- **Tamanho mínimo:** símbolo completo a partir de 40 px de altura na tela. Abaixo disso, use o `simbolo-reduzido`, sem o filete interno.
- **Foto de perfil:** `avatar-perfil.png`, símbolo em ouro sobre capela, ocupando 56% do lado para caber no recorte circular.
- **Não faça:** trocar as cores, distorcer, separar o "que" numa fonte diferente, contornar com sombra ou pôr o logo direto sobre a pintura.

## Cor

| Grupo | Tokens | Onde |
| --- | --- | --- |
| Base | `fundo`, `papel`, `tinta`, `tinta-suave`, `linha` | Fundo, cartão do santinho, texto, datas e créditos, filetes decorativos |
| Marca | `ouro` | Símbolo, moldura do santinho, referência bíblica, ornamento |
| Litúrgicas | `liturgico-verde`, `liturgico-roxo`, `liturgico-branco`, `liturgico-vermelho`, `liturgico-rosa` | Só pela `cor-do-dia`: cruz do selo e filete do nicho |
| Sobre cor | `sobre-cor` | Texto sobre preenchimento de ouro ou de cor litúrgica |

| Tempo ou celebração | Aponte `cor-do-dia` para |
| --- | --- |
| Tempo Comum | `liturgico-verde` |
| Advento e Quaresma | `liturgico-roxo` |
| Natal, Páscoa, festas do Senhor e de Nossa Senhora, santos não mártires | `liturgico-branco` (o ouro) |
| Mártires, apóstolos, Pentecostes, Domingo de Ramos, Sexta-feira Santa | `liturgico-vermelho` |
| Gaudete (3º Domingo do Advento) e Laetare (4º da Quaresma) | `liturgico-rosa` |

- No Santo do Dia, a cruz segue o santo: `liturgico-vermelho` para mártires, `liturgico-branco` para os demais.
- Branco vira ouro porque some sobre o pergaminho, como as vestes douradas dos dias solenes.
- Contraste: `tinta` e `tinta-suave` passam de 5,8:1 sobre `fundo` e `papel` nos dois temas; `ouro` e as litúrgicas passam de 4,5:1, então valem para a cruz, os filetes e textos curtos. `linha` é só decoração.
- Um cartão inteiro na cor do dia (o último do Evangelho) usa os valores do tema `pergaminho`, que são os tons fundos, com texto, cruz, ornamento e logo em `sobre-cor`.

## Tipografia

- **Cormorant Garamond** para o que se reza e se lê devagar: `titulo-capa`, `titulo`, `citacao`, `citacao-grande`, `oracao`.
- **Lato** para o que orienta: `selo`, `referencia`, `corpo`, `credito`, `assinatura`.
- Os tamanhos valem para a arte de 1080 px de largura. Texto que precisa ser lido no celular começa em 32 px; só o crédito desce a 24 px.
- Números em Lato. A Cormorant usa algarismos antigos, em que o 1 parece um I; por isso referência bíblica e datas ficam no `selo` ou na `referencia`.
- Palavra de uma letra (a, à, e, é, o) não fica no fim da linha: ligue-a à palavra seguinte com um espaço inseparável.
- Título, frase e texto centralizado saem com as linhas equilibradas (`text-wrap: balance`), inclusive o `corpo`.
- As duas famílias estão no Canva e no Google Fonts. Os arquivos em `fonts/` (licença OFL, em `licencas/`) servem às prévias e à web.

## Composição

- **Formatos:** feed em 1080 × 1350 (`post-largura`, `post-altura`); story e status do WhatsApp em 1080 × 1920 (`story-altura`).
- **Margens:** `espaco-5` nas quatro bordas do feed. O grid do perfil corta `recorte-grid` de cada lado, que fica dentro da margem. Nos stories, `espaco-6` no topo e na base.
- **Ordem de leitura:** selo no topo à esquerda, obra no nicho, título ou frase centralizados, assinatura centralizada na base.
- **Espaços:** `espaco-2` entre título e referência e entre o filete e a obra; `espaco-3` entre blocos e do nicho ao crédito; `espaco-4` do nicho ao título.
- Tudo é reto (`raio-reto`) menos o topo do nicho. Sem sombra, sem degradê sobre a obra, sem textura de papel envelhecido.

## Imagens

- Obras em domínio público (Wikimedia Commons, Metropolitan Museum, National Gallery of Art, Rijksmuseum, Art Institute of Chicago, Brooklyn Museum) ou fotos próprias de igrejas.
- No nicho, centralize o rosto e o gesto principal. Se o arco cortar algo essencial, aumente a largura do nicho antes de cortar a obra.
- Crédito em `credito`, no formato "Artista · Título · Museu", sob o nicho ou na legenda quando não couber.
- Nas prévias, os degradês dentro do nicho marcam o lugar da obra; não fazem parte da identidade.

## Tom e legendas

- Inspirador, acolhedor e autêntico, em linguagem acessível. Fale com "você".
- Primeira linha da legenda com a série e a data, para a busca: "Evangelho do dia, 16 de outubro de 2026 (Lc 12,1-7)".
- Frase sem fonte não vai ao ar: cite a obra, a carta ou o sermão na legenda e, quando couber, na arte.
- Emoji só na legenda, no máximo um, e nunca na arte.

## Componentes

- `Selo`, `Nicho` e `Assinatura` montam toda arte.
- `PostEvangelho`, `PostSanto`, `PostFesta`, `PostOracao`, `PostCoragem` e `StoryAngelus` são os modelos das séries; as séries sem modelo próprio (Olhe de Novo, Toda Bela, Por Dentro da Missa, Rezo por Você, Igreja Doméstica, Novenas) seguem o mais próximo deles, como mostra a `GradeFeed`.
